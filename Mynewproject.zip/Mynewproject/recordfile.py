import sqlite3

con = sqlite3.connect("record.db")
print("Database opened successfully")

con.execute(
    "create table recordtable (id INTEGER PRIMARY KEY AUTOINCREMENT,aid TEXT NOT NULL,qid TEXT UNIQUE NOT NULL, amount TEXT NOT NULL,task TEXT NOT NULL,state TEXT NOT NULL,reason TEXT NOT NULL)")

print("Table created successfully")

con.close()