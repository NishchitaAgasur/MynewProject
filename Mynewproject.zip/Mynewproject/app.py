
from flask import *
import sqlite3

app = Flask(__name__)


@app.route("/")
def index():
    return render_template("index.html");


@app.route("/add")
def add():
    return render_template("add.html")


@app.route("/savedetails", methods=["POST", "GET"])
def saveDetails():
    msg = "msg"
    if request.method == "POST":
        try:
            aid = request.form["aid"]
            qid = request.form["qid"]
            amount = request.form["amount"]
            task = request.form["task"]
            state = request.form["state"]
            reason = request.form["reason"]
            with sqlite3.connect("record.db") as con:
                cur = con.cursor()
                cur.execute("INSERT into recordtable (aid, qid, amount,task,state,reason) values (?,?,?,?,?,?)", (aid, qid, amount, task, state, reason))
                con.commit()
                msg = "record successfully Added"
        except:
            con.rollback()
            msg = "We can not add the record to the list"
        finally:
            return render_template("success.html", msg=msg)
            con.close()


@app.route("/display")
def display():
    con = sqlite3.connect("record.db")
    con.row_factory = sqlite3.Row
    cur = con.cursor()
    cur.execute("select * from recordtable")
    rows = cur.fetchall()
    return render_template("display.html", rows=rows)


@app.route("/delete")
def delete():
    return render_template("delete.html")


@app.route("/deleterecord", methods=["POST"])
def deleterecord():
    id = request.form["id"]
    with sqlite3.connect("record.db") as con:
        try:
            cur = con.cursor()
            cur.execute("delete from recordtable where id = ?", id)
            msg = "record successfully deleted"
        except:
            msg = "can't be deleted"
        finally:
            return render_template("delete_record.html", msg=msg)


if __name__ == "__main__":
    app.run(debug=True)